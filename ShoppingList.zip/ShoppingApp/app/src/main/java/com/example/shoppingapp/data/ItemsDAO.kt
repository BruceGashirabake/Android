package com.example.shoppingapp.data

import androidx.room.*

@Dao
interface ItemsDAO {
    @Query("SELECT * FROM todotable")
    fun getAllTodos(): List<Items>

    @Query("DELETE FROM todotable")
    fun deleteAll()

    @Insert
    fun insertTodo(todo: Items) : Long

    @Delete
    fun deleteTodo(todo: Items)

    @Update
    fun updateTodo(todo: Items)
}