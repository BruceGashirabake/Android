package com.example.shoppingapp.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.shoppingapp.R
import com.example.shoppingapp.ScrollingActivity
import com.example.shoppingapp.data.AppDatabase
import com.example.shoppingapp.data.Items
import com.example.shoppingapp.touch.ItemsTouchHelperCallback
import kotlinx.android.synthetic.main.items_row.view.*
import java.util.*

class ItemsAdapter : RecyclerView.Adapter<ItemsAdapter.ViewHolder> ,
    ItemsTouchHelperCallback {
    var todoItems = mutableListOf<Items>()

    val context: Context

    constructor(context: Context, todoList: List<Items>) : super() {
        this.context = context

        todoItems.addAll(todoList)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemsAdapter.ViewHolder {

        val itemsView = LayoutInflater.from(context).inflate(
            R.layout.items_row, parent, false
        )
        return ViewHolder(itemsView)
    }


    override fun getItemCount(): Int {
        return todoItems.size
    }
    fun removeAll() {
        todoItems.clear()
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: ItemsAdapter.ViewHolder, position: Int) {
        var todo = todoItems.get(holder.adapterPosition)

        holder.cbDone.text = todo.todoText
        holder.tvDescription.text = todo.todoText2
        holder.tvPrice.text = todo.todoText3
        holder.cbDone.isChecked = todo.done




        if (todo.category=="Food"){
            holder.ivCat.setImageResource(R.drawable.foo2)
        }else if (todo.category=="Electronics"){
            holder.ivCat.setImageResource(R.drawable.el2)
        }else if (todo.category=="Apparel"){
            holder.ivCat.setImageResource(R.drawable.ap3)
        }




        holder.btnDelete.setOnClickListener {
            removeTodo(holder.adapterPosition)
        }

        holder.btnEdit.setOnClickListener {
            (context as ScrollingActivity).showEditTodoDialog(
                todo, holder.adapterPosition
            )
        }

        holder.cbDone.setOnClickListener {
            todo.done = holder.cbDone.isChecked
            Thread{
                AppDatabase.getInstance(context).todoDao().updateTodo(todo)
            }.start()

        }
    }



    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val cbDone = itemView.cbDone
        val tvDescription = itemView.tvDescription
        val btnDelete = itemView.btnDelete
        val btnEdit = itemView.btnEdit
        val tvPrice=itemView.tvPrice
        val ivCat=itemView.ivCat
    }
    fun addTodo(todo: Items){
        todoItems.add(todo)

        //notifyDataSetChanged()
        notifyItemInserted(todoItems.lastIndex)
    }

    fun removeTodo(index: Int) {
        var t = Thread {
            AppDatabase.getInstance(context).todoDao().deleteTodo(todoItems.get(index))

            (context as ScrollingActivity).runOnUiThread {
                todoItems.removeAt(index)
                notifyItemRemoved(index)
            }
        }

        t.start()
    }

    fun updateTodo(todo: Items, index: Int){
        todoItems.set(index, todo)
        notifyItemChanged(index)
    }

    override fun onDismissed(position: Int) {
        removeTodo(position)
    }

    override fun onItemMoved(fromPosition: Int, toPosition: Int) {
        Collections.swap(todoItems, fromPosition, toPosition)
        notifyItemMoved(fromPosition, toPosition)
    }




}