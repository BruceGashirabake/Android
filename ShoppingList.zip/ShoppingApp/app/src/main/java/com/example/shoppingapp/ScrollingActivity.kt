package com.example.shoppingapp

import android.os.Bundle
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.shoppingapp.adapter.ItemsAdapter

import com.example.shoppingapp.data.AppDatabase
import com.example.shoppingapp.data.Items
import com.example.shoppingapp.touch.ItemsReyclerTouchCallback
import com.google.android.material.floatingactionbutton.FloatingActionButton


import kotlinx.android.synthetic.main.activity_scrolling.*

class ScrollingActivity : AppCompatActivity(),
    ItemsDialog.TodoHandler {

    companion object {
        public val KEY_TODO_EDIT = "KEY_TODO_EDIT"
    }


    lateinit var itemsAdapter: ItemsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scrolling)

        setSupportActionBar(toolbar)

        fab.setOnClickListener { view ->
            ItemsDialog().show(supportFragmentManager, "Dialog")
        }



        initRecyclerView()
        fab2.setOnClickListener{
            Thread{AppDatabase.getInstance(this@ScrollingActivity)
                .todoDao()
                .deleteAll()
                runOnUiThread{
                    itemsAdapter.removeAll()}}.start()
        }
    }



    fun initRecyclerView() {
        Thread {
            var todos = AppDatabase.getInstance(this@ScrollingActivity).
                todoDao().getAllTodos()

            runOnUiThread {
                itemsAdapter = ItemsAdapter(this, todos)
                recyclerTodo.adapter = itemsAdapter

                val touchCallbackList = ItemsReyclerTouchCallback(itemsAdapter)
                val itemTouchHelper = ItemTouchHelper(touchCallbackList)
                itemTouchHelper.attachToRecyclerView(recyclerTodo)
            }
        }.start()



        var itemDivider = DividerItemDecoration(this, DividerItemDecoration.VERTICAL)
        recyclerTodo.addItemDecoration(itemDivider)

        //recyclerTodo.layoutManager = GridLayoutManager(this, 2)
        //recyclerTodo.layoutManager = StaggeredGridLayoutManager(2,
          //StaggeredGridLayoutManager.VERTICAL)

    }

    var editIndex : Int = -1

    public fun showEditTodoDialog(todoToEdit: Items, todoIndex: Int) {
        editIndex = todoIndex

        val editTodoDialog = ItemsDialog()

        val bundle = Bundle()
        bundle.putSerializable(KEY_TODO_EDIT, todoToEdit)
        editTodoDialog.arguments = bundle

        editTodoDialog.show(supportFragmentManager, "EDITDIALOG")
    }


    override fun todoCreated(todo: Items) {
        Thread{
            var newId = AppDatabase.getInstance(this@ScrollingActivity).
                todoDao().insertTodo(todo)
            todo.id = newId

            runOnUiThread {
                itemsAdapter.addTodo(todo)
            }
        }.start()
    }

    override fun todoUpdated(todo: Items) {
        Thread {
            AppDatabase.getInstance(this@ScrollingActivity).
                todoDao().updateTodo(todo)

            runOnUiThread {
                itemsAdapter.updateTodo(todo, editIndex)
            }

        }.start()
    }
}
