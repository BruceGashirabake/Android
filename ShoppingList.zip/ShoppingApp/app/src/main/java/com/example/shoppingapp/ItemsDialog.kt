package com.example.shoppingapp

import android.app.AlertDialog
import android.app.Dialog
import android.content.ComponentCallbacks2
import android.content.Context
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Spinner
import androidx.fragment.app.DialogFragment
import com.example.shoppingapp.data.Items
import kotlinx.android.synthetic.*
import kotlinx.android.synthetic.main.items_dialog.*
import kotlinx.android.synthetic.main.items_dialog.view.*
import java.sql.Date

class ItemsDialog : DialogFragment() {

    interface TodoHandler {
        fun todoCreated(todo: Items)

        fun todoUpdated(todo: Items)
    }

    lateinit var todoHandler: TodoHandler

    override fun onAttach(context: Context?) {
        super.onAttach(context)

        if (context is TodoHandler) {
            todoHandler = context
        } else {
            throw RuntimeException(
                "The Activity is not implementing the TodoHandler interface."
            )
        }
    }

    lateinit var etTodoText: EditText
    lateinit var cbTodoDone: CheckBox
    lateinit var  etTodoText2: EditText
    lateinit var etTodoText3: EditText
    lateinit var itemSpinner: Spinner



    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialogBuilder = AlertDialog.Builder(requireContext())

        dialogBuilder.setTitle("Item to Shop")
        val dialogView = requireActivity().layoutInflater.inflate(
            R.layout.items_dialog, null
        )

        etTodoText = dialogView.etTodoText
        cbTodoDone = dialogView.cbTodoDone
        etTodoText2 = dialogView.etTodoText
        etTodoText3 = dialogView.etTodoText
        itemSpinner = dialogView.ItemSpinner

        val categoriesAdapter = ArrayAdapter.createFromResource(
            activity as Context,
            R.array.categories,
            android.R.layout.simple_spinner_item
        )
        categoriesAdapter.setDropDownViewResource(
            android.R.layout.simple_dropdown_item_1line
        )
        itemSpinner.adapter = categoriesAdapter

        dialogBuilder.setView(dialogView)

        // IF WE ARE IN EDIT MODE
        if (arguments != null) {
            if (arguments!!.containsKey(ScrollingActivity.KEY_TODO_EDIT)) {
                val todoItem = arguments!!.getSerializable(ScrollingActivity.KEY_TODO_EDIT) as Items

                etTodoText.setText(todoItem.todoText)
                etTodoText2.setText(todoItem.todoText2)
                etTodoText3.setText(todoItem.todoText3)

                if (todoItem.category == "Electronics") {
                    itemSpinner.setSelection(0)
                } else if (todoItem.category == "Food") {
                    itemSpinner.setSelection(1)
                } else {
                    itemSpinner.setSelection(2)
                }


                cbTodoDone.isChecked = todoItem.done

                dialogBuilder.setTitle("Edit todo")
            }
        }


        dialogBuilder.setPositiveButton("Ok") {
                dialog, which ->

            //
        }
        dialogBuilder.setNegativeButton("Cancel") { dialog, which ->
        }


        return dialogBuilder.create()
    }


    override fun onResume() {
        super.onResume()

        val positiveButton = (dialog as AlertDialog).getButton(Dialog.BUTTON_POSITIVE)
        positiveButton.setOnClickListener {

            if( etTodoText.text.isNotEmpty()){
                if (arguments != null && arguments!!.containsKey(ScrollingActivity.KEY_TODO_EDIT)) {
                    val todoToEdit = arguments!!.getSerializable(ScrollingActivity.KEY_TODO_EDIT) as Items
                    todoToEdit.todoText = etTodoText.text.toString()
                    todoToEdit.todoText2 = etTodoText2.text.toString()
                    todoToEdit.todoText3 = etTodoText.text.toString()
                    todoToEdit.done = cbTodoDone.isChecked
                    todoToEdit.category = itemSpinner.selectedItem.toString()

                    todoHandler.todoUpdated(todoToEdit)
                } else {
                    todoHandler.todoCreated(
                        Items(
                            null,
                            Date(System.currentTimeMillis()).toString(),
                            cbTodoDone.isChecked,
                            etTodoText.text.toString(),
                                    etTodoText2.text.toString(),
                                    etTodoText3.text.toString(),
                            itemSpinner.selectedItem.toString()


                        )
                    )

                }

                dialog.dismiss()
            } else {
                etTodoText.error = "This field can not be empty"


            }
        }
    }


}