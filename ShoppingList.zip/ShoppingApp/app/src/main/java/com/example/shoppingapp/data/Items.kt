package com.example.shoppingapp.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "todotable")
data class Items (
    @PrimaryKey(autoGenerate = true) var id: Long?,
    @ColumnInfo(name = "createdate") var createDate: String,
    @ColumnInfo(name = "done") var done: Boolean,
    @ColumnInfo(name = "todotext") var todoText: String,
    @ColumnInfo(name = "todotext2") var todoText2: String,
    @ColumnInfo(name = "todotext3") var todoText3: String,
    @ColumnInfo(name = "category") var category: String

) : Serializable