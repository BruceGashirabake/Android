package com.example.weatherinfo

import android.os.Bundle
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import com.example.weatherinfo.adapter.CityAdapter
import com.example.weatherinfo.data.City

import kotlinx.android.synthetic.main.activity_scrolling.*

class ScrollingActivity : AppCompatActivity(),
    CityDialog.CityHandler {

    lateinit var cityAdapter: CityAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scrolling)

        setSupportActionBar(toolbar)

        fab.setOnClickListener { view ->

            CityDialog().show(supportFragmentManager, "Dialog")

        }


        cityAdapter = CityAdapter(this)
        recyclerCity.adapter = cityAdapter
    }


    override fun cityCreated(city: City) {
        cityAdapter.addCity(city)
    }
}
