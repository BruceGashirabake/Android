package com.example.weatherinfo.adapter

import android.content.Context
import android.text.Layout
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.weatherinfo.R
import com.example.weatherinfo.data.City

import kotlinx.android.synthetic.main.city_dialog.view.*


class CityAdapter : RecyclerView.Adapter<CityAdapter.ViewHolder> {

    var cities = mutableListOf<City>(
    )

    val context: Context
    constructor(context: Context) : super() {
        this.context = context

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val cityView = LayoutInflater.from(context).inflate(
            R.layout.city_row, parent, false
        )
        return ViewHolder(cityView)
    }

    override fun getItemCount(): Int {
        return cities.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        var cityToAdd = cities.get(holder.adapterPosition)

        holder.cbCity.text = cityToAdd.cityText

        holder.cbCity.setOnClickListener {
            cityToAdd.done = holder.cbCity.isChecked

        }



    }


    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val cbCity = itemView.cbCity


    }

    fun addCity(city: City){
        cities.add(city)

        //notifyDataSetChanged()
        notifyItemInserted(cities.lastIndex)
    }


}