package com.example.weatherinfo.data

data class City (
    var done: Boolean,
    var cityText: String
)