package com.example.weatherinfo



import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.widget.CheckBox
import android.widget.EditText
import androidx.fragment.app.DialogFragment
import com.example.weatherinfo.data.City
import kotlinx.android.synthetic.main.city_dialog.view.*


import java.lang.RuntimeException
import java.util.*

class CityDialog : DialogFragment() {

    interface CityHandler{
        fun cityCreated(city: City)
    }

    lateinit var cityHandler: CityHandler

    override fun onAttach(context: Context?) {
        super.onAttach(context)

        if (context is CityHandler){
            cityHandler = context
        } else {
            throw RuntimeException(
                "The Activity is not implementing the TodoHandler interface.")
        }
    }

    lateinit var cityText: EditText
    lateinit var cityCheckDone: CheckBox


    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialogBuilder = AlertDialog.Builder(requireContext())

        dialogBuilder.setTitle("City Dialog")
        val dialogView = requireActivity().layoutInflater.inflate(
            R.layout.city_dialog, null
        )

        cityText= dialogView.etCity
        cityCheckDone= dialogView.cbCity

        dialogBuilder.setView(dialogView)


        dialogBuilder.setPositiveButton("Ok") {
                dialog, which ->

            cityHandler.cityCreated(
                City(
                    cityCheckDone.isChecked,
                    cityText.text.toString())
            )
        }
        dialogBuilder.setNegativeButton("Cancel") {
                dialog, which ->
        }


        return dialogBuilder.create()
    }


}