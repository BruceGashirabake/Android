package com.example.notes.SecondActivity

import androidx.room.*

@Dao
interface NotesDAO {
    @Query("SELECT * FROM notestable")
    fun getAllTodos(): List<Notes>

    @Insert
    fun insertTodo(todo: Notes): Long

    @Delete
    fun deleteTodo(todo: Notes)

    @Update
    fun updateNotes(todo: Notes)
}