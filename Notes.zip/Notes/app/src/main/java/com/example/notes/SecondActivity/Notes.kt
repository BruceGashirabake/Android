package com.example.notes.SecondActivity



import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "notestable")
data class Notes (
    @PrimaryKey(autoGenerate = true) var id: Long?,
    @ColumnInfo(name = "notesText") var notesText: String,
    @ColumnInfo(name = "notesTitle") var notesTitle: String


): Serializable











