package com.example.notes.SecondActivity

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.widget.EditText
import android.widget.Spinner
import androidx.fragment.app.DialogFragment
import com.example.notes.R
import kotlinx.android.synthetic.main.add_dialog.view.*
import java.lang.RuntimeException

class DialogAdd: DialogFragment(){
    interface NotesHandler{
        fun notesCreated(note: Notes)


        fun notesUpdated(note: Notes)
    }
    lateinit var notesHandler: NotesHandler
    lateinit var notesText:EditText
    lateinit var notesTitle: EditText


    override fun onAttach(context: Context?) {
        super.onAttach(context)

        if (context is NotesHandler){
            notesHandler= context
        } else {
            throw RuntimeException(
                "The Activity is not implementing the NotesHandler interface.")
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialogBuilder = AlertDialog.Builder(requireContext())

        dialogBuilder.setTitle("Notes Dialog")
        val dialogView = requireActivity().layoutInflater.inflate(
            R.layout.add_dialog, null
        )

        notesText= dialogView.etNotes
        notesTitle=dialogView.etTitle



        dialogBuilder.setView(dialogView)


        dialogBuilder.setPositiveButton("Ok") {
                dialog, which ->

            notesHandler.notesCreated(
                Notes(
                    null,
                    notesText.text.toString(),
                    notesTitle.text.toString()

                    )
            )
        }
        dialogBuilder.setNegativeButton("Cancel") {
                dialog, which ->
        }


        return dialogBuilder.create()
    }

}