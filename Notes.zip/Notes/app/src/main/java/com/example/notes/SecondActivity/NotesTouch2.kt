package com.example.notes.SecondActivity

interface NotesTouch2 {
    fun onDismissed(position: Int)
    fun onItemMoved(fromPosition: Int, toPosition: Int)
}