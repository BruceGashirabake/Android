package com.example.notes.SecondActivity

import android.content.Intent
import android.os.Bundle
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import androidx.recyclerview.widget.ItemTouchHelper
import com.example.notes.R
import kotlinx.android.synthetic.main.activity_scrolling.*
import kotlinx.android.synthetic.main.notes_row.*

class ScrollingActivity : AppCompatActivity(), DialogAdd.NotesHandler {


    companion object {
        public val KEY_TODO_EDIT = "KEY_TODO_EDIT"
    }

    lateinit var notesAdapter: NotesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scrolling)
        setSupportActionBar(toolbar)
        fab.setOnClickListener { view ->

            DialogAdd().show(supportFragmentManager, "Dialog")


        }
        initRecyclerView()


    }




    fun initRecyclerView() {
        Thread {
            var todos = AppDatabase.getInstance(this@ScrollingActivity).
                notesDao().getAllTodos()

            runOnUiThread {
                notesAdapter = NotesAdapter(this, todos)
                recyclerNotes.adapter = notesAdapter

                val touchCallbackList = NotesTouch1(notesAdapter)
                val itemTouchHelper = ItemTouchHelper(touchCallbackList)
                itemTouchHelper.attachToRecyclerView(recyclerNotes)
            }
        }.start()



        //var itemDivider = DividerItemDecoration(this, DividerItemDecoration.VERTICAL)
        //recyclerTodo.addItemDecoration(itemDivider)

        //recyclerTodo.layoutManager = GridLayoutManager(this, 2)
        //recyclerTodo.layoutManager = StaggeredGridLayoutManager(2,
        //    StaggeredGridLayoutManager.VERTICAL)

    }

    var editIndex : Int = -1




    override fun notesCreated(note: Notes) {
        Thread{
            var newId = AppDatabase.getInstance(this@ScrollingActivity).
                notesDao().insertTodo(note)
            note.id = newId

            runOnUiThread {
                notesAdapter.addNotes(note)
            }
        }.start()
    }

    override fun notesUpdated(notes: Notes) {
        Thread {
            AppDatabase.getInstance(this@ScrollingActivity).
                notesDao().updateNotes(notes)

            runOnUiThread {
                notesAdapter.updateNotes(notes, editIndex)
            }

        }.start()
    }

}
