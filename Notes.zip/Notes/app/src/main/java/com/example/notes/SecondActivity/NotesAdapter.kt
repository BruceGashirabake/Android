package com.example.notes.SecondActivity

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.notes.R
import kotlinx.android.synthetic.main.notes_row.view.*
import java.util.*

class NotesAdapter : RecyclerView.Adapter<NotesAdapter.ViewHolder>, NotesTouch2 {
    override fun onDismissed(position: Int) {
        removeNotes((position))
    }

    override fun onItemMoved(fromPosition: Int, toPosition: Int) {
        Collections.swap(notes, fromPosition, toPosition)
        notifyItemMoved(fromPosition, toPosition)
    }

    fun removeNotes(index:Int){

        var t = Thread{
            AppDatabase.getInstance(context).notesDao().deleteTodo(notes.get(index))
            (context as ScrollingActivity).runOnUiThread{
                notes.removeAt(index)
                notifyItemRemoved(index)
            }
        }
        t.start()

    }


    var notes = mutableListOf<Notes>(
    )

    val context: Context



    constructor(context: Context, notesList: List<Notes>) : super() {
        this.context = context

        notes.addAll(notesList)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val notesView = LayoutInflater.from(context).inflate(
            R.layout.notes_row, parent, false
        )
        return ViewHolder(notesView)
    }

    override fun getItemCount(): Int {
        return notes.size
    }
    fun removeNote(index: Int){
        notes.removeAt(index)
        notifyItemRemoved(index)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        var noteToAdd = notes.get(holder.adapterPosition)

        holder.tvNotes.text = noteToAdd.notesText
        holder.tvTitle.text=noteToAdd.notesTitle

        holder.btnDetails.setOnClickListener{
            val intent = Intent(context, ThirdActivity::class.java)

            (context as ScrollingActivity).startActivity(intent)
        }
        var rand= Random()
        var back=rand.nextInt(6)


        if (back==0){
            holder.cardView.setBackgroundResource(R.drawable.a)
        }
        else if (back==1){
            holder.cardView.setBackgroundResource(R.drawable.b)

        }else if (back==2){
            holder.cardView.setBackgroundResource(R.drawable.c)
        }else if (back==3){
            holder.cardView.setBackgroundResource(R.drawable.d)
        }else if (back==4){
            holder.cardView.setBackgroundResource(R.drawable.e)
        }else{
            holder.cardView.setBackgroundResource(R.drawable.f)
        }


        holder.btnDelete.setOnClickListener {
            removeNote(holder.adapterPosition)
        }






    }


    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvNotes = itemView.tvNotes
        val btnDelete=itemView.btnDelete
        val tvTitle=itemView.tvTitle
        val cardView=itemView.card_view
        val btnDetails=itemView.btnDetails


    }

    fun addNotes(note: Notes){
        notes.add(note)

        //notifyDataSetChanged()
        notifyItemInserted(notes.lastIndex)
    }


    fun updateNotes(todo: Notes, index: Int){
        notes.set(index, todo)
        notifyItemChanged(index)
    }



}